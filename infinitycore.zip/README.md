# InfinityCore
An attempt to create a foundry vtt module from scratch instead of copying from someone else
