export default class itemRoll extends Item {
    
}